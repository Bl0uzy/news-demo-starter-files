package main

var airVersion string
var goVersion string
